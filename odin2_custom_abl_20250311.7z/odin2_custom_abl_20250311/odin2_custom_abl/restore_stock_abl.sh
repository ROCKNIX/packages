#!/bin/sh

dd if="/sdcard/odin2_custom_abl/abl_stock.img" of=/dev/block/by-name/abl_a bs=1M
dd if="/sdcard/odin2_custom_abl/abl_stock.img" of=/dev/block/by-name/abl_b bs=1M
